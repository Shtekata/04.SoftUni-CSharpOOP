﻿namespace WildFarm.Models.Foods.Entities
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {

        }
    }
}
