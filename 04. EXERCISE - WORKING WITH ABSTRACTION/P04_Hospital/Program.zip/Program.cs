﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P04_Hospital
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
