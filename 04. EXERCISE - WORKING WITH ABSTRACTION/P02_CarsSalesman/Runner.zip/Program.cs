﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P02_CarsSalesman
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var runner = new Runner();
            runner.Start();
        }
    }

}
