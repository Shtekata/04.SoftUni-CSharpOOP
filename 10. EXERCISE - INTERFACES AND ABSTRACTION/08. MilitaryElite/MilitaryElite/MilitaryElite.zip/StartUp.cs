﻿namespace MilitaryElite
{
    using MilitaryElite.Core;
    using System;
    public class Program
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
