﻿namespace Telephony.Contracts
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
