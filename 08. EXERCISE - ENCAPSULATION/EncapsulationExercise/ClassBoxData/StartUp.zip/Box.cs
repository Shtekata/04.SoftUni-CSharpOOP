﻿namespace ClassBoxData
{
    using System;
    using System.Text;

    public class Box
    {
        private double length;
        private double width;
        private double height;
        public Box(double length,double width,double height)
        {
            Length = length;
            Width = width;
            Height = height;
        }
        public double Length
        {
            get =>length;
            private set
            {
                if (value > 0) length = value;
                else ArgExeption("Length");
            }
        }
        public double Width
        {
            get =>width;
            private set
            {
                if (value > 0) width = value;
                else ArgExeption("Width");
            }
        }
        public double Height
        {
            get =>height;
            private set
            {
                if (value > 0) height = value;
                else ArgExeption("Height");
            }
        }
        public double SurfaceArea()
        {
            return length * width * 2 + length * height * 2 + width * height * 2;
        }
        public double LateralSurfaceArea()
        {
            return SurfaceArea() - length * width * 2;
        }
        public double Volume()
        {
            return length * height * width;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Surface Area - {SurfaceArea():f2}");
            sb.AppendLine($"Lateral Surface Area - {LateralSurfaceArea():f2}");
            sb.AppendLine($"Volume - {Volume():f2}");
            return sb.ToString().TrimEnd();
        }
        private void ArgExeption(string value)
        {
            throw new ArgumentException($"{value} cannot be zero or negative.");
        }
    }
}
