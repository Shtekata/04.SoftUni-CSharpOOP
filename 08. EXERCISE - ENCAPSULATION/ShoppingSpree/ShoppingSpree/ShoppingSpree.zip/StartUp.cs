﻿namespace ShoppingSpree
{
    using ShoppingSpree.Core;

    public class Program
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
