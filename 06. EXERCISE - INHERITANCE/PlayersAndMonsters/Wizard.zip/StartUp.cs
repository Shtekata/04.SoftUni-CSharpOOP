﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var a = new SoulMaster("Asen", 9);
            System.Console.WriteLine(a);
        }
    }
}