﻿namespace Point_in_Rectangle
{
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            int[] coordinates = ParseInput();

            var topLeft = new Point(coordinates[0], coordinates[1]);
            var bottomRight = new Point(coordinates[2], coordinates[3]);

            var rectangle = new Rectangle(topLeft, bottomRight);
            var number = int.Parse(Console.ReadLine());

            for (int i = 0; i < number; i++)
            {
                var input = ParseInput();

                var point = new Point(input[0], input[1]);

                Console.WriteLine(rectangle.Contains(point));
            }
        }

        public static int[] ParseInput()
        {
            return Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();
        }
    }
}
